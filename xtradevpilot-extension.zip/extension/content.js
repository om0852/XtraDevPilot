// Listen for intercepted console logs
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  if (event.data && event.data.type === 'DEVPILOT_CONSOLE_LOG') {
    chrome.runtime.sendMessage({
      type: 'CONSOLE_LOG',
      data: { level: event.data.level, text: event.data.text, timestamp: event.data.timestamp }
    });
  }
});

// Respond to IDE Bridge requests
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'GET_DOM') {
    try {
      const html = document.documentElement.outerHTML;
      sendResponse({ result: html });
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return true;
  }

  if (request.action === 'GET_CLEAN_DOM') {
    try {
      const clone = document.documentElement.cloneNode(true);
      
      // Remove noisy tags
      const removeTags = ['script', 'style', 'svg', 'iframe', 'noscript', 'path'];
      removeTags.forEach(tag => {
        clone.querySelectorAll(tag).forEach(el => el.remove());
      });

      // Remove bloated attributes
      const allElements = clone.querySelectorAll('*');
      allElements.forEach(el => {
        el.removeAttribute('class');
        el.removeAttribute('style');
        // Keep id, name, href, type, placeholder, value, etc.
      });

      sendResponse({ result: clone.outerHTML });
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return true;
  }

  if (request.action === 'HIGHLIGHT_ELEMENT') {
    try {
      const el = document.querySelector(request.selector);
      if (el) {
        // Apply styling
        el.style.outline = '4px solid #FF5733';
        el.style.backgroundColor = 'rgba(255, 87, 51, 0.2)';
        el.style.transition = 'all 0.3s ease-in-out';
        
        // Scroll into view
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        sendResponse({ result: `Element ${request.selector} successfully highlighted.` });
      } else {
        sendResponse({ error: `Element with selector '${request.selector}' not found.` });
      }
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return true;
  }
  
  if (request.action === 'WAIT_FOR_CLICK') {
    let hoveredElement = null;

    const cleanup = () => {
      document.removeEventListener('mouseover', handleMouseOver, true);
      document.removeEventListener('click', handleClick, true);
      if (hoveredElement) {
        hoveredElement.style.outline = hoveredElement.dataset.oldOutline || '';
        hoveredElement.style.backgroundColor = hoveredElement.dataset.oldBg || '';
      }
    };

    const handleMouseOver = (e) => {
      e.stopPropagation();
      if (hoveredElement) {
        hoveredElement.style.outline = hoveredElement.dataset.oldOutline || '';
        hoveredElement.style.backgroundColor = hoveredElement.dataset.oldBg || '';
      }
      hoveredElement = e.target;
      hoveredElement.dataset.oldOutline = hoveredElement.style.outline;
      hoveredElement.dataset.oldBg = hoveredElement.style.backgroundColor;
      
      hoveredElement.style.outline = '3px solid #3b82f6';
      hoveredElement.style.backgroundColor = 'rgba(59, 130, 246, 0.2)';
    };

    const handleClick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      clearTimeout(timeoutId);
      cleanup();
      
      const clone = e.target.cloneNode(true);
      
      const removeTags = ['script', 'style', 'svg', 'iframe', 'noscript', 'path'];
      removeTags.forEach(tag => {
        clone.querySelectorAll(tag).forEach(el => el.remove());
      });

      const allElements = clone.querySelectorAll('*');
      allElements.forEach(el => {
        el.removeAttribute('class');
        el.removeAttribute('style');
      });
      clone.removeAttribute('class');
      clone.removeAttribute('style');

      sendResponse({ result: clone.outerHTML });
    };

    const timeoutId = setTimeout(() => {
      cleanup();
      sendResponse({ error: 'Timeout waiting for user click' });
    }, 59000);

    document.addEventListener('mouseover', handleMouseOver, true);
    document.addEventListener('click', handleClick, true);

    return true;
  }
  
  if (request.action === 'CLICK_ELEMENT') {
    try {
      const el = document.querySelector(request.selector);
      if (el) {
        el.click();
        sendResponse({ result: `Element ${request.selector} clicked successfully.` });
      } else {
        sendResponse({ error: `Element not found: ${request.selector}` });
      }
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return true;
  }

  if (request.action === 'TYPE_TEXT') {
    try {
      const el = document.querySelector(request.selector);
      if (el) {
        el.focus();
        el.value = request.text;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        sendResponse({ result: `Typed text into ${request.selector}` });
      } else {
        sendResponse({ error: `Element not found: ${request.selector}` });
      }
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return true;
  }

  if (request.action === 'MOCK_NETWORK_RESPONSE') {
    window.postMessage({
      type: 'DEVPILOT_ADD_MOCK',
      mock: {
        urlPattern: request.urlPattern,
        responseBody: request.responseBody,
        status: request.status
      }
    }, '*');
    sendResponse({ result: `Mock registered for ${request.urlPattern}` });
    return true;
  }

  if (request.action === 'CLEAR_NETWORK_MOCKS') {
    window.postMessage({ type: 'DEVPILOT_CLEAR_MOCKS' }, '*');
    sendResponse({ result: 'All mocks cleared' });
    return true;
  }
  
  if (request.action === 'GET_STORAGE') {
    try {
      const storageData = {
        localStorage: { ...window.localStorage },
        sessionStorage: { ...window.sessionStorage },
        cookie: document.cookie
      };
      sendResponse({ result: storageData });
    } catch (e) {
      sendResponse({ error: e.message });
    }
    return true; // Keep message channel open
  }
});
