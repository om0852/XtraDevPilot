function updateStats() {
  chrome.runtime.sendMessage({ action: 'GET_STATS' }, (response) => {
    if (chrome.runtime.lastError || !response) {
      console.error(chrome.runtime.lastError);
      return;
    }

    const { isConnected, totalNetwork, totalConsole } = response;

    const statusIndicator = document.getElementById('statusIndicator');
    const statusText = document.getElementById('statusText');
    const networkCount = document.getElementById('networkCount');
    const consoleCount = document.getElementById('consoleCount');

    if (isConnected) {
      statusIndicator.className = 'status-badge';
      statusText.textContent = 'Connected';
    } else {
      statusIndicator.className = 'status-badge disconnected';
      statusText.textContent = 'Disconnected';
    }

    networkCount.textContent = totalNetwork || 0;
    consoleCount.textContent = totalConsole || 0;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  updateStats();
  
  // Refresh stats every second while popup is open
  setInterval(updateStats, 1000);

  document.getElementById('refreshBtn').addEventListener('click', (e) => {
    e.preventDefault();
    updateStats();
  });

  document.getElementById('manageExtensionBtn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
  });
});
